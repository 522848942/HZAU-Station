module.exports = function (server) {
    const ChatModel = require('./db/models').ChatModel
    const io = require('socket.io')(server, {cors: true})
    io.on('connection', function (socket) {
        console.log('有客户端连接了服务器')
        socket.on('sendMsg', function({from, to, content}){
            console.log('服务器收到数据', {from, to, content})
            const chat_id = [from, to].sort().join('_')
            const create_time = Date.now()
            const chatModel = new ChatModel({chat_id, from, to, create_time, content})
            chatModel.save(function (err, chatMsg){
                io.emit('receiveMsg', chatMsg)
                console.log('向所有连接的客户端发送消息', chatMsg)
            })
        })
    })
}
