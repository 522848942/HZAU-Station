const md5 = require('blueimp-md5')
const mongoose = require('mongoose')
mongoose.connect('mongodb://localhost:27017/hzau-board_test',{ useUnifiedTopology: true, useNewUrlParser: true })
const conn = mongoose.connection
conn.on('connected', function (){
    console.log('connect success')
})
const userSchema = mongoose.Schema({
    username: {type: String, required: true},
    password: {type: String, required: true},
    header: {type: String}
})
const UserModel = mongoose.model('user', userSchema)


function testSave() {
    const userModel = new UserModel({username: 'a', password: md5('b')})
    userModel.save(function (error, user){
        console.log('save()', error, user)
    })
}

function  testFind() {
    UserModel.find(function (error, users){
        console.log('find()', error, users)
    })
    UserModel.findOne({_id: '6076c4d279d8e306c01b3934'},function(error, user){
        console.log('findOne()', error, user)
    })
}

function testUpdate() {
    UserModel.findByIdAndUpdate({_id: '6076c4d279d8e306c01b3934'},{username:'Jack'},function (error, oldUser){
        console.log('findByIdAndUpdate()', error, oldUser)
    })
}

function testDelete() {
    UserModel.remove({}, function (error, doc) {
        console.log('remove()', error, doc)
    })
}

