const md5 = require('blueimp-md5')
const mongoose = require('mongoose')
mongoose.connect('mongodb://localhost:27017/hzau-board',{ useUnifiedTopology: true, useNewUrlParser: true })
const conn = mongoose.connection
mongoose.set('useFindAndModify', false)
conn.on('connected', () => {
    console.log('connect success')
})
//用户
const userSchema = mongoose.Schema({
    username: {type: String, required: true},
    password: {type: String, required: true},
    header: {type: String},
    username_2: {type: String},
})
const UserModel = mongoose.model('user', userSchema)
exports.UserModel = UserModel
//话题
const TopicSchema = mongoose.Schema({
    type: {type: String, required: true},
    topicHeader: {type: String, required: true},
    name: {type: String, required: true},
    describe:{type: String }
})
const TopicModel = mongoose.model('topic', TopicSchema)
exports.TopicModel = TopicModel
//文章
const ArticleSchema = mongoose.Schema({
    picList: {type: Array, required: true},
    text: {type: String, required: true},
    writerName: {type: String, required: true},
    writerProfile: {type: String, required: true},
    writerName_2: {type: String, required: true},
    writerid: {type: String, required: true},
    topicName: {type: String, required: true},
    time: {type: String, required: true},
    url: {type: String}
})
const ArticleModel = mongoose.model('article', ArticleSchema)
exports.ArticleModel = ArticleModel
//chats集合文档结构
const chatSchema = mongoose.Schema({
    from: {type: String, require: true},//发送用户的id
    to: {type: String, required: true},//接收用户的id
    chat_id: {type: String, required: true},//from和to组成的字符串
    content: {type: String, required: true},//内容
    read: {type: Boolean, default: false},//标识是否已读
    create_time: {type: Number}//创建时间
})
const ChatModel = mongoose.model('chat', chatSchema)
exports.ChatModel = ChatModel

function  testFind() {
    TopicModel.find( function (error, article){
        console.log(error, article)
    })
}
testFind()
function testSave() {
    const topicModel = new TopicModel({
        type: "你问我答",
        topicHeader: "topic12",
        name: "吃顿好的！",
        describe:"华农有哪些好吃的？"
    })
    topicModel.save(function (error, topic){
        console.log('save()', error, topic)
    })
}
//testSave()
function testUpdate() {
    UserModel.findByIdAndUpdate({_id: '607e83b8a9865a2ca888e3f2'},{username:'Jack'},function (error, oldUser){
        console.log('findByIdAndUpdate()', error, oldUser)
    })
}
//testUpdate()
function testDelete() {
    TopicModel.remove({_id: '60a13b23e74e5f2e908972c7'}, function (error, doc) {
        console.log('remove()', error, doc)
    })
}
//testDelete()
