var express = require('express');
var router = express.Router();

const md5 = require('blueimp-md5')
const UserModel = require('../db/models').UserModel
const TopicModel = require('../db/models').TopicModel
const ArticleModel = require('../db/models').ArticleModel
const ChatModel = require('../db/models').ChatModel
const filter = {password: 0, __v: 0}//滤掉password和__v因为不需要传到前端去
const article_filter ={writerName: 0}//读取文章的时候滤掉学号因为不需要传到前端去
//用户登录路由
router.post('/login', function (req, res){
  const {username, password} = req.body
  UserModel.findOne({username, password:md5(password)}, filter,function(err, user) {
    if(user) {
      res.cookie('userid', user._id, {maxAge: 1000*60*60*24})
      res.send({code: 0, data: user})
    } else {
      res.send({code: 1, msg: 'ID or password wrong'})
    }
  })
})
//更新用户信息路由,添加头像和第二用户名
router.post('/update', function (req, res){
  const userid = req.cookies.userid
  if(!userid){
    return res.send({code: 1, msg: 'please login'})
  }
  const user = req.body
  UserModel.findByIdAndUpdate({_id: userid}, user, function (error, oldUser){
    if(!oldUser){
      res.clearCookie('userid')
      return res.send({code: 1, msg: 'please login'})
    }else{
      const {_id, username} = oldUser
      const data = Object.assign(user, {_id, username})
      res.send({code: 0, data: data})
    }
  })
})
//注册确认用户是否已经注册
router.post('/userconfirm', function (req, res){
  const {username} = req.body
  UserModel.findOne({username},function(error, user){
    if(user) {
      res.send({code: 1, msg: 'ID has been Confirmed'})
    } else {
      res.send({code: 0, data: user})
    }
  })
})
//保存用户名和密码
router.post('/userregister', function (req, res){
  const {username, password} = req.body
  new UserModel({username: username, password: md5(password)}).save(function (error, user){
    const data = {username, _id: user._id}
    res.send({code:0, data: data})
  })
})
//获取用户信息路由
router.get('/user', function(req, res){
  const userid = req.cookies.userid
  if(!userid) {
    return res.send({code: 1, msg: 'please login'})
  }
  UserModel.findOne({_id: userid}, filter, function (error, user) {
    res.send({code: 0, data: user})
  })
})
//话题产生
router.post('/topicupload', function (req, res){
  const {type, topicHeader, name, describe} = req.body
  new TopicModel({ type: type, topicHeader: topicHeader, name: name, describe: describe}).save(function (error, user){
    res.send({code:0, msg: 'Up Load Success'})
  })
})
//获取话题路由
router.get('/topic', function (req, res){
  TopicModel.find(function (err, topic) {
    res.send({code: 0, data: topic})
  })
})
//获取单个话题信息
router.post('/onetopic', function (req, res){
  const {name} = req.body
  TopicModel.findOne({name: name} ,function (err, topic) {
    res.send({code: 0, data: topic})
  })
})
//根据文章类型获取文章路由
router.post('/article', function (req, res){
  const {topicName} = req.body
  if (topicName){
    ArticleModel.find({topicName: topicName}, article_filter, function (err, article) {
      res.send({code: 0, data: article.reverse()})
    })
  }else{
    ArticleModel.find(null,article_filter, function (err, article) {
      res.send({code: 0, data: article.reverse()})
    })
  }
})
//获取单个文章全文
router.post('/onearticle', function (req, res){
  const {articleid} = req.body
  ArticleModel.findOne({_id: articleid}, article_filter, function (err, article) {
    res.send({code: 0, data: article})
  })
})
//文章上传路由
router.post('/articleupload', function (req, res){
  const {picList, text, writerName, writerName_2, writerProfile, topicName, writerid} = req.body
  var timeNow = Date().split(' ')
  var time = [timeNow[0],timeNow[1],timeNow[2],timeNow[3],timeNow[4]].join(' ')
  new ArticleModel({ picList: picList, text: text, writerName: writerName, writerName_2: writerName_2, writerProfile: writerProfile, topicName: topicName, time: time, writerid: writerid}).save(function (error, user){
    res.send({code:0, msg: 'Up Load Success'})
  })
})
//获取当前用户聊天所有相关聊天信息列表
router.get('/msglist', function(req, res){
  const userid = req.cookies.userid
  UserModel.find(function(err, userDocs){
    const users = {}
    userDocs.forEach(doc => {
      users[doc._id] = {username: doc.username_2, header: doc.header}
    })
    ChatModel.find({'$or': [{from: userid}, {to: userid}]}, filter, function (err, chatMsgs){
      res.send({code: 0,data: {users, chatMsgs}})
    })
  })
})
router.post('/readmsg', function(req, res){
  const from = req.body.from
  const to = req.cookies.userid
  ChatModel.update({from, to, read: false}, {read: true}, {multi: true}, function (err, doc){
    console.log('/readmsg', doc)
    res.send({code: 0, data: doc.nModified})
  })
})


module.exports = router;
